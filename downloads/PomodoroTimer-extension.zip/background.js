const DEFAULT_SETTINGS = {
  focusMin: 25,
  breakMin: 5,
  longBreakMin: 15,
  longBreakEvery: 4,
  volumePct: 70,
  autoStartFocus: true
};

const ALARM_PHASE_END = "phase_end";
const ALARM_BADGE_TICK = "badge_tick";
const OFFSCREEN_URL = "offscreen.html";

let settings = { ...DEFAULT_SETTINGS };

let state = {
  status: "stopped",
  round: 0,
  phaseStartAt: 0,
  phaseEndAt: 0,
  todayCount: 0,
  todayKey: "",
  streakCurrent: 0,
  streakBest: 0,
  lastFocusDayKey: "",
  todos: []
};

let offscreenCreationPromise = null;

chrome.runtime.onInstalled.addListener(() => {
  initialize();
});

chrome.runtime.onStartup.addListener(() => {
  initialize();
});

initialize();

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    if (message?.action === "START_POMODORO") {
      await startFocusPhase();
      sendResponse({ ok: true });
      return;
    }

    if (message?.action === "STOP_POMODORO") {
      await stopPomodoro();
      sendResponse({ ok: true });
      return;
    }

    if (message?.action === "SKIP_PHASE") {
      await skipPhase();
      sendResponse({ ok: true });
      return;
    }

    if (message?.action === "GET_STATE") {
      sendResponse(getStateForUi());
      return;
    }

    if (message?.action === "UPDATE_SETTINGS") {
      settings = sanitizeSettings(message.settings || {});
      await persistSettings();
      await syncAudioVolume();
      sendResponse({ ok: true, settings });
      return;
    }

    if (message?.action === "ADD_TODO") {
      const text = String(message.text || "").trim();
      if (!text) {
        sendResponse({ ok: false, error: "Empty todo" });
        return;
      }
      state.todos.unshift({
        id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        text,
        done: false
      });
      await persistState();
      sendResponse({ ok: true, todos: state.todos });
      return;
    }

    if (message?.action === "ADD_TODOS") {
      const items = Array.isArray(message.items) ? message.items : [];
      const normalized = items
        .map((item) => String(item || "").trim())
        .filter(Boolean)
        .slice(0, 30);

      if (normalized.length === 0) {
        sendResponse({ ok: false, error: "No todos" });
        return;
      }

      const mapped = normalized.map((text) => ({
        id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        text,
        done: false
      }));

      state.todos = [...mapped.reverse(), ...state.todos];
      await persistState();
      sendResponse({ ok: true, todos: state.todos });
      return;
    }

    if (message?.action === "TOGGLE_TODO") {
      const id = String(message.id || "");
      state.todos = state.todos.map((item) => {
        if (item.id !== id) {
          return item;
        }
        return { ...item, done: !item.done };
      });
      await persistState();
      sendResponse({ ok: true, todos: state.todos });
      return;
    }

    if (message?.action === "UPDATE_TODO") {
      const id = String(message.id || "");
      const text = String(message.text || "").trim();
      if (!id || !text) {
        sendResponse({ ok: false, error: "Invalid todo update" });
        return;
      }

      state.todos = state.todos.map((item) => {
        if (item.id !== id) {
          return item;
        }
        return { ...item, text };
      });

      await persistState();
      sendResponse({ ok: true, todos: state.todos });
      return;
    }

    if (message?.action === "DELETE_TODO") {
      const id = String(message.id || "");
      state.todos = state.todos.filter((item) => item.id !== id);
      await persistState();
      sendResponse({ ok: true, todos: state.todos });
      return;
    }

    sendResponse({ ok: false, error: "Unknown action" });
  })();

  return true;
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARM_PHASE_END) {
    await handlePhaseEnd();
    return;
  }

  if (alarm.name === ALARM_BADGE_TICK) {
    await updateBadge();
  }
});

async function initialize() {
  const stored = await chrome.storage.local.get(["pomodoroState", "pomodoroSettings"]);

  if (stored.pomodoroState) {
    state = { ...state, ...stored.pomodoroState };
  }

  if (!Array.isArray(state.todos)) {
    state.todos = [];
  }

  if (stored.pomodoroSettings) {
    settings = sanitizeSettings(stored.pomodoroSettings);
  }

  const changed = ensureTodayState();
  if (changed) {
    await persistState();
  }

  await reconcileTimer();
}

function getStateForUi() {
  ensureTodayState();

  return {
    status: state.status,
    round: state.round,
    remainingSec: getRemainingSec(),
    progressPct: getProgressPct(),
    todayCount: state.todayCount,
    streakCurrent: state.streakCurrent,
    streakBest: state.streakBest,
    nextPhase: getNextPhase(state.status),
    settings,
    todos: state.todos
  };
}

function getRemainingSec() {
  if (state.status === "stopped" || !state.phaseEndAt) {
    return 0;
  }

  return Math.max(0, Math.ceil((state.phaseEndAt - Date.now()) / 1000));
}

function getNextPhase(currentStatus) {
  if (currentStatus === "focus") {
    const nextRound = state.round + 1;
    return nextRound % settings.longBreakEvery === 0 ? "long_break" : "break";
  }

  if (currentStatus === "break" || currentStatus === "long_break") {
    return "focus";
  }

  return "focus";
}

function getDurationSecForStatus(status) {
  if (status === "focus") {
    return focusDurationSec();
  }
  if (status === "break") {
    return breakDurationSec();
  }
  if (status === "long_break") {
    return longBreakDurationSec();
  }
  return 0;
}

function getProgressPct() {
  if (state.status === "stopped") {
    return 0;
  }

  const totalSec = getDurationSecForStatus(state.status);
  if (totalSec <= 0) {
    return 0;
  }

  const remainingSec = getRemainingSec();
  const elapsedSec = Math.max(0, totalSec - remainingSec);
  return Math.min(100, Math.max(0, Math.round((elapsedSec / totalSec) * 100)));
}

function focusDurationSec() {
  return Math.round(settings.focusMin * 60);
}

function breakDurationSec() {
  return Math.round(settings.breakMin * 60);
}

function longBreakDurationSec() {
  return Math.round(settings.longBreakMin * 60);
}

async function startFocusPhase() {
  await setPhase("focus", focusDurationSec());
}

async function startBreakPhase(isLongBreak) {
  const status = isLongBreak ? "long_break" : "break";
  const durationSec = isLongBreak ? longBreakDurationSec() : breakDurationSec();
  await setPhase(status, durationSec);
}

async function setPhase(status, durationSec) {
  state.status = status;
  state.phaseStartAt = Date.now();
  state.phaseEndAt = state.phaseStartAt + durationSec * 1000;

  await chrome.alarms.clear(ALARM_PHASE_END);
  chrome.alarms.create(ALARM_PHASE_END, { when: state.phaseEndAt });
  chrome.alarms.create(ALARM_BADGE_TICK, { periodInMinutes: 1 });

  if (status === "focus") {
    await stopBreakAudio();
    await closeOffscreenDocument();
  } else {
    await playBreakAudio();
  }

  await notifyPhase(status);
  await persistState();
  await updateBadge();
}

async function handlePhaseEnd() {
  if (state.status === "stopped") {
    return;
  }

  if (getRemainingSec() > 0) {
    chrome.alarms.create(ALARM_PHASE_END, { when: state.phaseEndAt });
    return;
  }

  if (state.status === "focus") {
    ensureTodayState();
    state.round += 1;
    state.todayCount += 1;
    registerFocusDay();
    const isLongBreak = state.round % settings.longBreakEvery === 0;
    await startBreakPhase(isLongBreak);
    return;
  }

  if (state.status === "break" || state.status === "long_break") {
    if (settings.autoStartFocus) {
      await startFocusPhase();
    } else {
      await stopPomodoro();
    }
  }
}

async function stopPomodoro() {
  state.status = "stopped";
  state.phaseStartAt = 0;
  state.phaseEndAt = 0;

  await chrome.alarms.clear(ALARM_PHASE_END);
  await chrome.alarms.clear(ALARM_BADGE_TICK);
  await stopBreakAudio();
  await closeOffscreenDocument();
  await persistState();
  await updateBadge();
}

async function reconcileTimer() {
  const changed = ensureTodayState();
  if (changed) {
    await persistState();
  }

  if (state.status === "stopped") {
    await chrome.alarms.clear(ALARM_PHASE_END);
    await chrome.alarms.clear(ALARM_BADGE_TICK);
    await stopBreakAudio();
    await closeOffscreenDocument();
    await updateBadge();
    return;
  }

  if (!state.phaseEndAt) {
    await stopPomodoro();
    return;
  }

  if (!state.phaseStartAt) {
    const durationSec = getDurationSecForStatus(state.status);
    state.phaseStartAt = Math.max(0, state.phaseEndAt - durationSec * 1000);
    await persistState();
  }

  if (getRemainingSec() <= 0) {
    await handlePhaseEnd();
    return;
  }

  chrome.alarms.create(ALARM_PHASE_END, { when: state.phaseEndAt });
  chrome.alarms.create(ALARM_BADGE_TICK, { periodInMinutes: 1 });

  if (state.status === "focus") {
    await stopBreakAudio();
    await closeOffscreenDocument();
  } else {
    await playBreakAudio();
  }

  await updateBadge();
}

function ensureTodayState() {
  const today = getTodayKey();
  if (state.todayKey === today) {
    return false;
  }

  state.todayKey = today;
  state.todayCount = 0;
  return true;
}

function getTodayKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function dayDiff(a, b) {
  const aDate = new Date(`${a}T00:00:00`);
  const bDate = new Date(`${b}T00:00:00`);
  const ms = bDate - aDate;
  return Math.round(ms / 86400000);
}

function registerFocusDay() {
  const today = state.todayKey || getTodayKey();
  const last = state.lastFocusDayKey;

  if (!last) {
    state.streakCurrent = 1;
    state.streakBest = Math.max(state.streakBest, 1);
    state.lastFocusDayKey = today;
    return;
  }

  if (last === today) {
    return;
  }

  if (dayDiff(last, today) === 1) {
    state.streakCurrent += 1;
  } else {
    state.streakCurrent = 1;
  }

  state.streakBest = Math.max(state.streakBest, state.streakCurrent);
  state.lastFocusDayKey = today;
}

function sanitizeSettings(candidate) {
  return {
    focusMin: parseMinute(candidate.focusMin, DEFAULT_SETTINGS.focusMin),
    breakMin: parseMinute(candidate.breakMin, DEFAULT_SETTINGS.breakMin),
    longBreakMin: parseMinute(candidate.longBreakMin, DEFAULT_SETTINGS.longBreakMin),
    longBreakEvery: parseInterval(candidate.longBreakEvery, DEFAULT_SETTINGS.longBreakEvery),
    volumePct: parseVolume(candidate.volumePct, DEFAULT_SETTINGS.volumePct),
    autoStartFocus: parseBoolean(candidate.autoStartFocus, DEFAULT_SETTINGS.autoStartFocus)
  };
}

function parseMinute(value, fallback) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return fallback;
  }

  const clamped = Math.min(180, Math.max(1, parsed));
  return Math.round(clamped * 10) / 10;
}

function parseInterval(value, fallback) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return fallback;
  }

  const rounded = Math.round(parsed);
  return Math.min(12, Math.max(2, rounded));
}

function parseVolume(value, fallback) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return fallback;
  }

  return Math.min(100, Math.max(0, Math.round(parsed)));
}

function parseBoolean(value, fallback) {
  if (typeof value === "boolean") {
    return value;
  }
  return fallback;
}

async function skipPhase() {
  if (state.status === "stopped") {
    await startFocusPhase();
    return;
  }

  if (state.status === "focus") {
    ensureTodayState();
    state.round += 1;
    state.todayCount += 1;
    registerFocusDay();
    const isLongBreak = state.round % settings.longBreakEvery === 0;
    await startBreakPhase(isLongBreak);
    return;
  }

  if (state.status === "break" || state.status === "long_break") {
    await startFocusPhase();
  }
}

async function updateBadge() {
  if (state.status === "stopped") {
    await chrome.action.setBadgeText({ text: "" });
    return;
  }

  const minLeft = Math.max(0, Math.ceil(getRemainingSec() / 60));
  const text = String(minLeft);
  const color = state.status === "focus" ? "#16a34a" : "#0f172a";

  await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setBadgeText({ text });
}

async function persistState() {
  await chrome.storage.local.set({ pomodoroState: state });
}

async function persistSettings() {
  await chrome.storage.local.set({ pomodoroSettings: settings });
}

async function notifyPhase(status) {
  const data = getNotificationContent(status);

  await chrome.notifications.create({
    type: "basic",
    iconUrl: "icon.png",
    title: data.title,
    message: data.message,
    priority: 2
  });
}

function getNotificationContent(status) {
  if (status === "focus") {
    return {
      title: "Fokus",
      message: `Fokuspass startat: ${settings.focusMin} minuter.`
    };
  }

  if (status === "break") {
    return {
      title: "Paus",
      message: `Paus startad: ${settings.breakMin} minuter.`
    };
  }

  if (status === "long_break") {
    return {
      title: "Längre paus",
      message: `Paus startad: ${settings.longBreakMin} minuter.`
    };
  }

  return {
    title: "Pomodoro",
    message: "Timeruppdatering."
  };
}

async function hasOffscreenDocument() {
  if (chrome.runtime.getContexts) {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)]
    });
    return contexts.length > 0;
  }

  return false;
}

async function ensureOffscreenDocument() {
  if (await hasOffscreenDocument()) {
    return;
  }

  if (!offscreenCreationPromise) {
    offscreenCreationPromise = chrome.offscreen.createDocument({
      url: OFFSCREEN_URL,
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Play local break audio during Pomodoro break phases."
    }).finally(() => {
      offscreenCreationPromise = null;
    });
  }

  await offscreenCreationPromise;
}

async function syncAudioVolume() {
  if (!(await hasOffscreenDocument())) {
    return;
  }

  await chrome.runtime.sendMessage({
    target: "offscreen",
    type: "SET_VOLUME",
    volumePct: settings.volumePct
  });
}

async function playBreakAudio() {
  await ensureOffscreenDocument();

  await chrome.runtime.sendMessage({
    target: "offscreen",
    type: "SET_VOLUME",
    volumePct: settings.volumePct
  });

  await chrome.runtime.sendMessage({
    target: "offscreen",
    type: "PLAY_BREAK"
  });
}

async function stopBreakAudio() {
  if (!(await hasOffscreenDocument())) {
    return;
  }

  await chrome.runtime.sendMessage({
    target: "offscreen",
    type: "STOP_AUDIO"
  });
}

async function closeOffscreenDocument() {
  if (!(await hasOffscreenDocument())) {
    return;
  }

  await chrome.offscreen.closeDocument();
}
