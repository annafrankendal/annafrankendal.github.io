const statusEl = document.getElementById("status");
const musicStateEl = document.getElementById("musicState");
const nextPhaseEl = document.getElementById("nextPhase");
const statusRowEl = document.getElementById("statusRow");
const nextPhaseRowEl = document.getElementById("nextPhaseRow");
const roundEl = document.getElementById("round");
const todayCountEl = document.getElementById("todayCount");
const streakEl = document.getElementById("streak");
const timeLeftEl = document.getElementById("timeLeft");
const progressFillEl = document.getElementById("progressFill");
const progressLabelEl = document.getElementById("progressLabel");
const settingsNoteEl = document.getElementById("settingsNote");
const volumeValueEl = document.getElementById("volumeValue");

const focusMinInput = document.getElementById("focusMinInput");
const breakMinInput = document.getElementById("breakMinInput");
const longBreakMinInput = document.getElementById("longBreakMinInput");
const longBreakEveryInput = document.getElementById("longBreakEveryInput");
const volumeInput = document.getElementById("volumeInput");
const autoStartInput = document.getElementById("autoStartInput");

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const skipBtn = document.getElementById("skipBtn");
const saveSettingsBtn = document.getElementById("saveSettingsBtn");
const presetClassicBtn = document.getElementById("presetClassicBtn");
const presetDeepBtn = document.getElementById("presetDeepBtn");

const todoInput = document.getElementById("todoInput");
const todoBulkInput = document.getElementById("todoBulkInput");
const addTodoBtn = document.getElementById("addTodoBtn");
const addSingleTodoBtn = document.getElementById("addSingleTodoBtn");
const todoListEl = document.getElementById("todoList");

let settingsInitialized = false;

startBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ action: "START_POMODORO" });
  await refresh();
});

stopBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ action: "STOP_POMODORO" });
  await refresh();
});

skipBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ action: "SKIP_PHASE" });
  await refresh();
});

saveSettingsBtn.addEventListener("click", async () => {
  const payload = {
    focusMin: Number(focusMinInput.value),
    breakMin: Number(breakMinInput.value),
    longBreakMin: Number(longBreakMinInput.value),
    longBreakEvery: Number(longBreakEveryInput.value),
    volumePct: Number(volumeInput.value),
    autoStartFocus: Boolean(autoStartInput.checked)
  };

  const result = await chrome.runtime.sendMessage({
    action: "UPDATE_SETTINGS",
    settings: payload
  });

  if (!result?.ok) {
    settingsNoteEl.textContent = "Kunde inte spara tider. Försök igen.";
    return;
  }

  applySettings(result.settings);
  settingsNoteEl.textContent = "Inställningar sparade.";
  await refresh();
});

presetClassicBtn.addEventListener("click", () => {
  focusMinInput.value = "25";
  breakMinInput.value = "5";
  longBreakMinInput.value = "15";
  longBreakEveryInput.value = "4";
  settingsNoteEl.textContent = "Preset vald: Klassisk.";
});

presetDeepBtn.addEventListener("click", () => {
  focusMinInput.value = "50";
  breakMinInput.value = "10";
  longBreakMinInput.value = "20";
  longBreakEveryInput.value = "4";
  settingsNoteEl.textContent = "Preset vald: Deep Work.";
});

volumeInput.addEventListener("input", () => {
  volumeValueEl.textContent = `${volumeInput.value}%`;
});

addTodoBtn.addEventListener("click", addTodoBulk);
addSingleTodoBtn.addEventListener("click", addTodo);
todoInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    addTodo();
  }
});
todoBulkInput.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
    addTodoBulk();
  }
});

function formatTime(totalSeconds) {
  const sec = Math.max(0, totalSeconds | 0);
  const mm = String(Math.floor(sec / 60)).padStart(2, "0");
  const ss = String(sec % 60).padStart(2, "0");
  return `${mm}:${ss}`;
}

function formatStatus(status) {
  if (status === "focus") {
    return "fokus";
  }
  if (status === "break") {
    return "paus";
  }
  if (status === "long_break") {
    return "längre paus";
  }
  return "stoppad";
}

function applySettings(settings) {
  if (!settings) {
    return;
  }

  focusMinInput.value = String(settings.focusMin);
  breakMinInput.value = String(settings.breakMin);
  longBreakMinInput.value = String(settings.longBreakMin);
  longBreakEveryInput.value = String(settings.longBreakEvery);
  volumeInput.value = String(settings.volumePct);
  autoStartInput.checked = Boolean(settings.autoStartFocus);
  volumeValueEl.textContent = `${settings.volumePct}%`;
}

function nextPhaseText(state) {
  const nextLabel = formatStatus(state.nextPhase);

  if (state.status === "stopped") {
    return "Tryck Start Pomodoro för att börja";
  }

  return `${nextLabel} om ${formatTime(state.remainingSec)}`;
}

function renderTodos(todos) {
  todoListEl.textContent = "";

  if (!Array.isArray(todos) || todos.length === 0) {
    const li = document.createElement("li");
    li.className = "todo-item";
    li.innerHTML = "<span>Inga uppgifter ännu.</span>";
    todoListEl.appendChild(li);
    return;
  }

  for (const item of todos) {
    const li = document.createElement("li");
    li.className = "todo-item";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = Boolean(item.done);
    checkbox.addEventListener("change", async () => {
      await chrome.runtime.sendMessage({ action: "TOGGLE_TODO", id: item.id });
      await refresh();
    });

    const text = document.createElement("span");
    text.textContent = item.text;
    if (item.done) {
      text.className = "todo-done";
    }

    const del = document.createElement("button");
    del.className = "todo-delete";
    del.textContent = "Ta bort";
    del.addEventListener("click", async () => {
      await chrome.runtime.sendMessage({ action: "DELETE_TODO", id: item.id });
      await refresh();
    });

    const edit = document.createElement("button");
    edit.className = "todo-edit";
    edit.textContent = "Redigera";
    edit.addEventListener("click", async () => {
      const nextText = prompt("Redigera punkt:", item.text);
      if (nextText === null) {
        return;
      }
      const trimmed = nextText.trim();
      if (!trimmed) {
        return;
      }
      await chrome.runtime.sendMessage({ action: "UPDATE_TODO", id: item.id, text: trimmed });
      await refresh();
    });

    li.appendChild(checkbox);
    li.appendChild(text);
    li.appendChild(edit);
    li.appendChild(del);
    todoListEl.appendChild(li);
  }
}

async function addTodo() {
  const text = normalizeTodoText(todoInput.value);
  if (!text) {
    return;
  }

  const result = await chrome.runtime.sendMessage({ action: "ADD_TODO", text });
  if (result?.ok) {
    todoInput.value = "";
    todoInput.focus();
    await refresh();
  }
}

async function addTodoBulk() {
  const raw = todoBulkInput.value || "";
  const items = raw
    .split("\n")
    .map((line) => normalizeTodoText(line))
    .filter(Boolean);

  if (items.length === 0) {
    return;
  }

  const result = await chrome.runtime.sendMessage({ action: "ADD_TODOS", items });
  if (result?.ok) {
    todoBulkInput.value = "";
    todoInput.focus();
    await refresh();
  }
}

function normalizeTodoText(value) {
  return String(value || "")
    .trim()
    .replace(/^[-*]\s+/, "")
    .replace(/^\[\s?\]\s*/i, "")
    .trim();
}

async function refresh() {
  const state = await chrome.runtime.sendMessage({ action: "GET_STATE" });

  statusEl.textContent = formatStatus(state.status);
  musicStateEl.textContent =
    state.status === "break" || state.status === "long_break"
      ? "spelar nu"
      : "kommer i paus";
  nextPhaseEl.textContent = nextPhaseText(state);
  roundEl.textContent = String(state.round);
  todayCountEl.textContent = String(state.todayCount || 0);
  streakEl.textContent = `${state.streakCurrent || 0} dagar`;
  timeLeftEl.textContent = formatTime(state.remainingSec);
  progressFillEl.style.width = `${state.progressPct || 0}%`;
  progressLabelEl.textContent = `${state.progressPct || 0}% klart`;

  const isRunning = state.status !== "stopped";
  statusRowEl.style.display = isRunning ? "flex" : "none";
  nextPhaseRowEl.style.display = isRunning ? "flex" : "none";
  skipBtn.style.display = isRunning ? "block" : "none";

  if (!settingsInitialized && state.settings) {
    applySettings(state.settings);
    settingsInitialized = true;
  }

  renderTodos(state.todos || []);
}

refresh();
setInterval(refresh, 1000);
