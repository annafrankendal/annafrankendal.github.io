const TRACKS = [
  "break.mp3",
  "break1.mp3",
  "break2.mp3",
  "break3.mp3"
];

const audio = new Audio();
audio.loop = true;
audio.volume = 0.7;

let availableTracksPromise = null;
let lastTrackIndex = -1;

async function resolveAvailableTracks() {
  if (availableTracksPromise) {
    return availableTracksPromise;
  }

  availableTracksPromise = (async () => {
    const checks = await Promise.all(TRACKS.map(async (file) => {
      const url = chrome.runtime.getURL(file);
      try {
        const response = await fetch(url);
        return response.ok ? url : null;
      } catch (_error) {
        return null;
      }
    }));

    const tracks = checks.filter(Boolean);
    return tracks.length > 0 ? tracks : [chrome.runtime.getURL("break.mp3")];
  })();

  return availableTracksPromise;
}

function pickTrack(tracks) {
  if (tracks.length === 1) {
    lastTrackIndex = 0;
    return tracks[0];
  }

  let nextIndex = Math.floor(Math.random() * tracks.length);
  if (nextIndex === lastTrackIndex) {
    nextIndex = (nextIndex + 1) % tracks.length;
  }
  lastTrackIndex = nextIndex;
  return tracks[nextIndex];
}

function setVolume(volumePct) {
  const raw = Number(volumePct);
  if (!Number.isFinite(raw)) {
    return;
  }
  const clamped = Math.min(100, Math.max(0, Math.round(raw)));
  audio.volume = clamped / 100;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.target !== "offscreen") {
    return;
  }

  if (message.type === "SET_VOLUME") {
    setVolume(message.volumePct);
    sendResponse({ ok: true });
    return;
  }

  if (message.type === "PLAY_BREAK") {
    resolveAvailableTracks().then((tracks) => {
      const nextTrack = pickTrack(tracks);
      if (audio.src !== nextTrack) {
        audio.src = nextTrack;
      }
      return audio.play();
    }).then(() => {
      sendResponse({ ok: true });
    }).catch((error) => {
      sendResponse({ ok: false, error: String(error) });
    });
    return true;
  }

  if (message.type === "STOP_AUDIO") {
    audio.pause();
    audio.currentTime = 0;
    sendResponse({ ok: true });
  }
});
